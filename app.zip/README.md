# AWS X-Ray Elastic Beanstalk NodeJS template
Starting template for the BackSpace Academy X-Ray lab of the AWS Certified Developer pathway.
